public class MercedesTire extends Tire{
    public MercedesTire(String tire_name) {
        super(tire_name);
    }
}
