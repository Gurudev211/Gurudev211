public class AudiHeadlight extends Headlight{
    public AudiHeadlight(String headlight_name) {
        super(headlight_name);
    }
}
