public abstract class Tire {

    String tire_name;

    public Tire(String tire_name) {
        this.tire_name = tire_name;
    }

    public String getTire_name() {
        return tire_name;
    }
}
