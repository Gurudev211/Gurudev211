public class AudiTire extends Tire{
    public AudiTire(String tire_name) {
        super(tire_name);
    }
}
