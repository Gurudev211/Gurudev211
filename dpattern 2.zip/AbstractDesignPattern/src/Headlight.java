public abstract class Headlight {

    String headlight_name;

    public Headlight(String headlight_name) {
        this.headlight_name = headlight_name;
    }

    public String getHeadlight_name() {
        return headlight_name;
    }
}
