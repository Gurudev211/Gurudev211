public class MercedesHeadlight extends Headlight{
    public MercedesHeadlight(String headlight_name) {
        super(headlight_name);
    }
}
